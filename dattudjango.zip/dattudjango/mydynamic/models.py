from django.db import models
from django.utils.safestring import mark_safe
# Create your models here.

class product(models.Model):
    name = models.CharField(max_length=50)
    price = models.FloatField()
    desc = models.TextField()
    proimage = models.ImageField(upload_to='photos')
    
    def product_image(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.proimage.url))
    
    product_image.allows_tags=True