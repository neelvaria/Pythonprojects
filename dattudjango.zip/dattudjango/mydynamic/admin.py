from django.contrib import admin
from .models import *
# Register your models here.

class productdata(admin.ModelAdmin):
    list_display = ["name","price","desc","proimage","product_image"]
admin.site.register(product,productdata)