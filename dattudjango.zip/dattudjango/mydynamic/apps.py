from django.apps import AppConfig


class MydynamicConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mydynamic'
